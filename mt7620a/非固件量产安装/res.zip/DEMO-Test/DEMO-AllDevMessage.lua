
function module_init()
  ---- register callback event
  register_event("from_mqtt_all_dev");    --function from_mqtt_all_dev(flag,dev,mqtt,topic,buf,len) end
  register_event("from_mqtt_base_cmd");   --function from_mqtt_base_cmd(mqtt,topic,buf,len) end
  register_event("to_mqtt_all_dev");      --function to_mqtt_all_dev(flag,dev,mqtt,topic,buf,len) end

  return nil;
end

function from_mqtt_all_dev(flag,dev,mqtt,topic,buf,len) 
  print("--->>from_mqtt_all_dev=",flag,dev,mqtt,topic,buf,len );
end

function from_mqtt_base_cmd(mqtt,topic,buf,len) 
  print("--->>from_mqtt_base_cmd=",mqtt,topic,buf,len);
end

function to_mqtt_all_dev(flag,dev,mqtt,topic,buf,len)
  print("<<---to_mqtt_all_dev=",mqtt,topic,buf,len);
end;