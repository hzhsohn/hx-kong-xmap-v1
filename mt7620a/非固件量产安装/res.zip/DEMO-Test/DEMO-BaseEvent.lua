------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------

local scene0="";


function module_init()
  register_event("from_user");        --function from_user(flag,dev,command,parameter) end
  register_event("user_use_scene");   --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_mqtt");        --function from_mqtt(flag,dev,topic,buf,len) end
  
  --register_event("from_mqtt_all_dev");    --function from_mqtt_all_dev(flag,dev,mqtt,topic,buf,len) end
  --register_event("from_mqtt_base_cmd");   --function from_mqtt_base_cmd(mqtt,topic,buf,len) end
  --register_event("to_mqtt_all_dev");      --function to_mqtt_all_dev(flag,dev,mqtt,topic,buf,len) end
  
  return "DEMO2";
end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)
       print("from_user=",flag,dev,command,parameter);
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
       print(utf8_gb2312("执行场景"),scene_name);
end

------------------------------------------------------------
--内部MQTT网络设备发出的数据
function from_mqtt(flag,dev,topic,buf,len)         
       print("from_mqtt=",topic ,len,flag ,dev);
end
