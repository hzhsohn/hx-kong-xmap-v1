------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local tcpc=require "tcpclient" 
local tr=require "timer" 

function module_init()

  sleep(100);
  ipv4=tcpc.gethost("www.hx-kong.com")
  print("TCPClient gethost-------",ipv4);
  
  --连接到本机
  sock=tcpc.init("connect_cb","recv_cb","disconnect_cb");
  tcpc.bind(sock,3333);
  tid=tr.init("tcp_timer",0,2000,true);
  

  --释放sock连接
  --tcpc.free(sock);  

  return nil;
end

function connect_cb(is_ok)
  if is_ok then
    print(utf8_gb2312("服务器连接成功"));
    sleep(100);
    ip,port=tcpc.get_serv_info(sock);
    print(utf8_gb2312("服务器信息="), ip, port);
    sleep(100);
    ip,port=tcpc.get_cli_info(sock);
    print(utf8_gb2312("本地端口="), ip, port);
    sleep(100);
  else
    print(utf8_gb2312("连接服务器失败"));
  end;
end

function recv_cb(data,len)
    print("recvfrom()--"..data.."  len="..len.."  addr="..ip..":"..port);
end

function disconnect_cb()
    print(utf8_gb2312("与服务器断开连接"));
end

function tcp_timer()
  --print("tcp_timer()--send... sock="..sock);
  if(tcpc.is_connected(sock))then
     tcpc.send(sock,"abcdef",6);
  else
     print(utf8_gb2312("TCP已经断开连接"));     
      --连接服务器
      tcpc.connect(sock,"127.0.0.1",6665);
  end
end
