------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local md=require "minidata" 

function module_init()


--协议处理函数
  buf,len=md.create(string.char(0x44,0x45,0x46),3);
  bbstr=byte_string(buf,len);
  print("minidata create",bbstr,len);
  
  ret=md.is_effect(buf,len);
  print("minidata is_effect",ret);
  
  param,param_len=md.getframe(buf,len);
  ccstr=byte_string(param,param_len);
  print("minidata getframe",ccstr,param_len);
  
  return nil;
end
