local xmap=require "xmap"

function module_init()

--[[
  在wall文档加入,MSD组件条件
  <msd_if type="IR" condition="AA BB CC DD" box_name="ccc1"/>
]]--
  ------获取MSD条件数组
  mifary=xmap.msd_if("IR");
  for i,v in ipairs(mifary) do
    print(i,"wall="..v[1],"type="..v[2],"condition="..v[3],"box_name="..v[4]);
  end

  return nil;
end
