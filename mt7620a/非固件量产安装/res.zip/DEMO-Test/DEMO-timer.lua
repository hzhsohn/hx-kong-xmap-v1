------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local tr=require "timer" 
local tid=0;
local a=10;

function module_init()

  --参数1 回调函数, 参数2 开始时间, 参数3 间隔时间, 参数4 是否循环
  tid=tr.init("handle",1000,1000,false);
  --tr.start(tid);
  --tr.stop(tid);  
  
  return nil;
end

function handle()

    print("timer.handle()----".."tid="..tid.."---a="..a.."----get_interval="..tr.get_interval(tid));
    a=a+1;
    
    --设置定时器间隔
    tr.set_interval(tid,1000-a*a);
    
    if(a>100) then
        tr.free(tid);
    end    
end
