------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local sk=require "udp" 
local tr=require "timer" 

function module_init()

  print("gethost-------",sk.gethost("www.hx-kong.com"));
  sock=sk.init("recvfrom");
  sk.bind(sock,6666);
  tid=tr.init("udp_timer",0,1000,true);
  --sk.free(sock);  
  
  return nil;
end

function recvfrom(data,len,ip,port)
   print("recvfrom()--"..data.."  len="..len.."  addr="..ip..":"..port);
end

function udp_timer()
  print("udp_timer()--send... sock="..sock);
  sk.send(sock,"abcdef",6,"192.168.1.5",4321);
end
