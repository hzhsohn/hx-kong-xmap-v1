------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local xmap=require "xmap" 

function module_init()

  
--推送功能
  xmap.push_notify("default","我是一只小虫子");
  
--返回数据到客户端里,flag,dev,command,parameter
  flag="KG4";
  dev="001";
  xmap.msd_udata(flag,dev,"state","{\"state\":[0,1,0,1]}");
  
--发送内容abc到设备flag,dev,buff,bufflen
  xmap.msd_send(flag,dev,string.char(98,99,100),3);
  
--全局广播
  xmap.msd_a("playscreen","pjson");

--执行WALL的box场景
  xmap.box("wall-1.config","cup1");
  
  return nil;
end
