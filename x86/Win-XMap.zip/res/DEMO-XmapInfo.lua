------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local xmap=require "xmap" 

function module_init()

  print("current dpid     -------",xmap.get_caid());
  print("current caid     -------",xmap.get_dpid());
  print("current devname  -------",xmap.get_name());
  print("current uuid     -------",xmap.get_uuid());
    
  --获取MSD设备
  msdlist=xmap.online_msd();
  for i,v in ipairs(msdlist) do
    print("online msd",i,v);
  end 

  --获取wall列表
  walllst=xmap.wall_list();
  for i,v in ipairs(walllst) do
    print("wall list",i,v);
  end 
  
  --获取wall列表
  wallele=xmap.wall_element("wall-1.config");
  for i,v in ipairs(wallele) do
    print("wall element",i,v);
  end 

  return nil;
end
