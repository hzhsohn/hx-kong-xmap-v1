------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local hxnet=require "hxnet" 

function module_init()


--协议处理函数
--isCrc=1支持CRC16的校验

  da,dalen=hxnet.create("MKG",string.char(0x01,0x02,0x03),3,isCrc);  
  bbstr=byte_string(da,dalen);
  print("hxnet create",bbstr,dalen);
  
  ret=hxnet.is_effect(da,dalen);
  print("hxnet is_effect",ret);
    
  prol_flag,param,param_len=hxnet.getframe(da,dalen);  
  ccstr=byte_string(param,param_len);
  print("hxnet getframe",prol_flag,ccstr,param_len);
  
  return nil;
end
