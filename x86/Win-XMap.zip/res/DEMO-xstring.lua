------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------

local xstr=require "xstring" 

function module_init()
 
--分割
  ta=xstr.split("1123456,abcdef",",");
  print(ta[0]);
  print(ta[1]);
  
--分组
  tary,tcount=xstr.split_char("a1123456abcdef");
  print("tary length="..tcount);
  for i=0,#tary,1 do
    print(i,tary[i]);
  end
  
  return nil;
end

