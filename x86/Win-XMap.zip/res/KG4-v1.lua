--[[
协议取用hx-net格式
字符串标识为 KG
------->发至MCU
0x00 & ::::::::::::: 查询状态
0x01 & 循环[uchar 通道号码0~通道数量n排列的状态] ::::::::::::: 批量通道开关
0x02 & uchar 通道号码,uchar 开或关0_1 ::::::::::::: 单通道开关控制
------->返回至控制端
0x10 & 循环[uchar 通道号码0~n的状态] ::::::::::::: 通道状态

--开关字节格式
0x01-0x64 代表亮度百分比
0xA0-0xAF 代表点控模式,0x10=通断1毫秒 ,0x11=100毫秒,0x12=200毫秒...0x1F=1.5秒


]]--

local xmap=require "xmap" 
local hxnet=require "hxnet" 
local sjson=require "sjson" 
local scene0="";

function module_init()
  ------注册事件
  register_event("user_use_scene");     --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_user");          --function user_get_scene(flag,dev,command,parameter) end
  register_event("from_mqtt");          --function from_mqtt(flag,dev,buf,len) end
  
  ------创建场景0
  scene0=sjson.attr(scene0,"url","http://xmap.hx-kong.com/ico");
  scene0=sjson.array(scene0, "id", "0");
  scene0=sjson.array(scene0, "scene", "group=0&name=ALLON&ico=on1.png&txt=全开");
  scene0=sjson.array(scene0, "scene", "group=0&name=ALLOFF&ico=off1.png&txt=全关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S1&ico=on1.png&txt=1路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S3&ico=on1.png&txt=2路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S5&ico=on1.png&txt=3路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S7&ico=on1.png&txt=4路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S2&ico=off1.png&txt=1路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S4&ico=off1.png&txt=2路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S6&ico=off1.png&txt=3路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S8&ico=off1.png&txt=4路关");
  
  ------返回硬件标识
  return "KG4";
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
    --print("KG4 user_use_scene="..scene_name,parameter);
    if scene_name=="ALLON" then 
        print(utf8_gb2312("全开"));
        da,dalen=hxnet.create("KG",string.char(0x01,1,1,1,1),5);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="ALLOFF" then
        print(utf8_gb2312("全关"));
        da,dalen=hxnet.create("KG",string.char(0x01,0,0,0,0),5);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    
    --单路控制
    elseif scene_name=="S1" then
        da,dalen=hxnet.create("KG",string.char(0x02,0,1),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="S2" then
        da,dalen=hxnet.create("KG",string.char(0x02,0,0),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);

    elseif scene_name=="S3" then
        da,dalen=hxnet.create("KG",string.char(0x02,1,1),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="S4" then
        da,dalen=hxnet.create("KG",string.char(0x02,1,0),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
   
    elseif scene_name=="S5" then
        da,dalen=hxnet.create("KG",string.char(0x02,2,1),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="S6" then
        da,dalen=hxnet.create("KG",string.char(0x02,2,0),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
        
    elseif scene_name=="S7" then
        da,dalen=hxnet.create("KG",string.char(0x02,3,1),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="S8" then
        da,dalen=hxnet.create("KG",string.char(0x02,3,0),3);
        bf,le=hex2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    else
        print(utf8_gb2312("执行了未知场景->"),flag,dev,scene_name);
    end;
end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)    
        print("from_user--",flag,dev,command,parameter);
    if "scene"== command then
        --print(utf8_gb2312("获取场景内容"));
        if "0"==parameter then
            --print(flag ,dev, scene0);
            xmap.msd_udata(flag,dev,"scene", scene0);
        end
    elseif "state"== command then         
        --print(utf8_gb2312("查询硬件状态"));
        bf,le=hxnet.create("KG",string.char(0x00),1);
        xmap.msd_send(flag,dev,bf,le);
    end
end

------------------------------------------------------------
--MSD设备的数据
function from_mqtt(flag,dev,buf,len) 
    --print("---------------------------------------");
    --print("KG4 from_mqtt=",len,flag ,dev);
    --解出单片机数据
    msdbuf,msdlen=json2hex(buf,len);
    --print("---msd msdlen  --> "..msdlen);
    --print("---msd msdlen  --> "..byte_string(msdbuf,msdlen));
    
    prol_flag,param,param_len=hxnet.getframe(msdbuf,msdlen);
    if prol_flag=="KG" then                  --判断是否为 KG协议
        if string.byte(param,1)==0x10 then
             sj= string.format("{\"state\":[%d,%d,%d,%d]}",string.byte(param,2),string.byte(param,3),string.byte(param,4),string.byte(param,5))
             xmap.msd_udata(flag,dev,"state",sj);
             --print(sj);
         end
    end
end
