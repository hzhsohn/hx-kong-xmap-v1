------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------

local xmap=require "xmap" 
local scene0="";


function module_init()
  register_event("from_user");        --function from_user(flag,dev,command,parameter) end
  register_event("user_use_scene");   --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_mqtt");        --function from_mqtt(flag,dev,topic,buf,len) end
  
  ------创建场景0
  scene0=sjson_attr(scene0,"url","http://192.168.1.101/playscreen");
  scene0=sjson_array(scene0, "id", "0");
  scene0=sjson_array(scene0, "scene", "group=0&name=play&ico=0.jpg&txt=主信息决定播放");
  scene0=sjson_array(scene0, "scene", "group=0&name=playimg&ico=1.jpg&txt=播放图片");
  scene0=sjson_array(scene0, "scene", "group=0&name=playvideo&ico=2.jpg&txt=播放视频");
  
  scene0=sjson_array(scene0, "scene", "group=0&name=allplay&ico=0.jpg&txt=全部机器播主页信息");
  scene0=sjson_array(scene0, "scene", "group=0&name=allplayimg&ico=1.jpg&txt=全部机器播图片");
  scene0=sjson_array(scene0, "scene", "group=0&name=allplayvideo&ico=2.jpg&txt=全部机器播视频");
  
  ------返回硬件标识
  return "playscreen";
end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)  
    print("from_user",command,parameter);
    if "scene"== command then
        print(flag ,dev,scene_id, scene0);
        xmap.msd_udata(flag,dev,"scene", scene0);
    end
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
    if scene_name=="play" then 
        print(utf8_gb2312("执行=主信息决定播放"));
        pjson="{\"playscreen-cmd\":\"reload\"}";
        xmap.msd_send(flag,dev,pjson,#pjson);
    elseif scene_name=="allplay" then 
        print(utf8_gb2312("执行=主信息决定播放"));
        pjson="{\"playscreen-cmd\":\"reload\"}";
        xmap.msd_a("playscreen",pjson);
        
        
    elseif scene_name=="playimg" then 
        print(utf8_gb2312("执行=播放图片"));
        pjson="{\"playscreen-cmd\":\"mode1\"}";
        xmap.msd_send(flag,dev,pjson,#pjson);
    elseif scene_name=="allplayimg" then 
        print(utf8_gb2312("执行=播放图片"));
        pjson="{\"playscreen-cmd\":\"mode1\"}";
        xmap.msd_a("playscreen",pjson);
        
        
    elseif scene_name=="playvideo" then
        print(utf8_gb2312("执行=播放视频"));
        pjson="{\"playscreen-cmd\":\"mode2\"}";
        xmap.msd_send(flag,dev,pjson,#pjson);
    elseif scene_name=="allplayvideo" then
        print(utf8_gb2312("执行=播放视频"));
        pjson="{\"playscreen-cmd\":\"mode2\"}";
        xmap.msd_a("playscreen",pjson);
        
        
    else
        print(utf8_gb2312("未知场景"),utf8_gb2312(scene_name));
    end;
end

------------------------------------------------------------
--内部MQTT网络设备发出的数据
function from_mqtt(flag,dev,topic,buf,len) 
        
        print("---------------------------------------");
        print("playscreen from_mqtt=",topic ,len,flag ,dev);
   
end
