------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local xmap=require "xmap" 
local sjson=require "sjson" 
local scene0="";


function module_init()
  register_event("from_user");        --function from_user(flag,dev,command,parameter) end
  register_event("user_use_scene");   --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_mqtt");        --function from_mqtt(flag,dev,topic,buf,len) end
  
  ------创建场景0
  scene0=sjson.attr(scene0,"url","http://xmap.hx-kong.com/ico");
  scene0=sjson.array(scene0, "id", "0");
  scene0=sjson.array(scene0, "scene", "group=0&name=scene_1&ico=on1.png&txt=测试1");
  scene0=sjson.array(scene0, "scene", "group=0&name=scene_2&ico=off1.png&txt=测试2");
  
  ------返回硬件标识
  return "DEMO0";
end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)    
    if "scene"== command then
        print(utf8_gb2312("获取场景内容"));
        if 0==parameter then      
            print(flag ,dev,scene_id, scene0);
            xmap.msd_udata(flag,dev,"scene", scene0);
        end
    elseif "state"== command then         
        print(utf8_gb2312("查询硬件状态"));
        bf,le=buf2json(string.char(0xAA,0x4D,0x4B,0x47,0x00,0x01,0x00,0xBA),8);
        xmap.msd_send(flag,dev,bf,le);
    end
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
    if scene_name=="scene_1" then 
        print(utf8_gb2312("执行=测试场景1"));
    elseif scene_name=="scene_2" then
        print(utf8_gb2312("执行=测试场景2"));
    else
        print(utf8_gb2312("未知场景"),utf8_gb2312(scene_name));
    end;
end

------------------------------------------------------------
--内部MQTT网络设备发出的数据
function from_mqtt(flag,dev,topic,buf,len) 
        
        print("---------------------------------------");
        print("DEMO from_mqtt=",topic ,len,flag ,dev);
        
        --解出单片机数据,前提是硬件也是转换过16进制数据
        msdbuf,msdlen=json2buf(buf,len);
        print("----------------------------------------");
        print("---mqtt data topic="..topic,"len="..len);
        print("---msd data flag        --> "..flag);
        print("---msd data devname     --> "..dev);
        print("---msd data len         --> "..msdlen);
        print("---msd data buf         --> "..byte_string(msdbuf,msdlen));
        
end
