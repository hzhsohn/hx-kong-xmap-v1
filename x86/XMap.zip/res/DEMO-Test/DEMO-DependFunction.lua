------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------


function module_init()
 
--休眠函数
  sleep(100);
 
--加密函数
  str=md5(str)
  str=base64_encode(str)
  str=base64_decode(str)
  
--函数处理,字符串转换
  str=gb2312_utf8(str);
  str=utf8_gb2312(str);
  str=byte_string(buf16,len);
  strHex=string_byte(str);
  enstr=urlencode("http://a.com");
  destr=urldecode(enstr);
--数据转换
  str,len=string_byte("0x33_0x34_0x35_100_101_102");
  str=byte_string(strHex,strlen);
  --
  bf,le=buf2json(da,dalen);
  msdbuf,msdlen=json2buf(buf,len);
  --
  hex,hexlen=sbuf2hex("42434445");
  buf,buflen=hex2sbuf(hex,hexlen);
  --
  bf,le=hex2json(da,dalen);
  msdbuf,msdlen=json2hex(buf,len);
    
  return "DEMO1";
end

