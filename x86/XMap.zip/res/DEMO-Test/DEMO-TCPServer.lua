------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local tcps=require "tcpserver" 

function module_init()

  sleep(100);

  --连接到本机
  tcpServA=tcps.init("accept_cb","recv_cb","disconnect_cb",1234);
  if(tcpServA~=0)then
    print(utf8_gb2312("lua TCPServer 初始化成功 port="),1234);
  else 
    print(utf8_gb2312("lua TCPServer 初始化失败"));
  end

  --释放sock连接
  --tcps.free(tcpServA);  

  return nil;
end

function accept_cb(sockID)
  print(utf8_gb2312("lua TCPServer 有新客户端连接 sockID="),sockID);
end

function recv_cb(sockID,data,len)
    ip="0.0.0.0";
    port=0;
    ip,port=tcps.get_cli_info(tcpServA,sockID);
    print("tcp server recvfrom()--"..data.."  len="..len.."  addr="..ip..":"..port);
    tcps.send(tcpServA,sockID,data,len);

    --如果只有3个字节直接断开
    if(3>=len)then
      tcps.disconnect(tcpServA,sockID);
    end
end

function disconnect_cb(sockID)
    print(utf8_gb2312("与服务器断开连接"));
end
