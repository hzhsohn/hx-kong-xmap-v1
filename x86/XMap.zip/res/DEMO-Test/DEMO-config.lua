------------------------------------------------------------
------------------------------------------------------------
--
-- 当前文件格式为utf-8
--
------------------------------------------------------------
local cfg=require "config" 

function module_init()

  --读写配置
  str=cfg.read_config("A_ BC","a1");
  ret=cfg.write_config("A_ BC","a1","123456789");
  
  print("config write ret="..ret);
  print("config read str="..str);
  
  return nil;
end
