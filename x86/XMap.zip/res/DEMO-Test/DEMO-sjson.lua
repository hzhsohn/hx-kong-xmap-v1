local sjson=require "sjson" 
local scene0="";

function module_init()

  ------创建场景0
  scene0=sjson.attr(scene0,"url","http://xmap.hx-kong.com/ico");
  scene0=sjson.array(scene0, "id", "0");
  scene0=sjson.array(scene0, "scene", "group=0&name=ALLON&ico=on1.png&txt=全开");
  scene0=sjson.array(scene0, "scene", "group=0&name=ALLOFF&ico=off1.png&txt=全关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S1&ico=on1.png&txt=1路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S3&ico=on1.png&txt=2路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S5&ico=on1.png&txt=3路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S7&ico=on1.png&txt=4路开");
  scene0=sjson.array(scene0, "scene", "group=0&name=S2&ico=off1.png&txt=1路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S4&ico=off1.png&txt=2路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S6&ico=off1.png&txt=3路关");
  scene0=sjson.array(scene0, "scene", "group=0&name=S8&ico=off1.png&txt=4路关");
  
  print(sjson.array_nil(scene0, "test_null"));
  
  print(sjson.attr_get(scene0,"url"));
  print(sjson.array_count(scene0,"scene"));
  print(sjson.array_get(scene0,"scene",0));

  return nil;
end
