--[[
红外传感器模块
]]--

local xmap=require "xmap"
local sjson=require "sjson" 
local xstr=require "xstring" 
local scene0="";
local mifary={};

function module_init()
  ------注册事件
  register_event("user_use_scene");     --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_user");          --function user_get_scene(flag,dev,command,parameter) end
  register_event("from_mqtt");          --function from_mqtt(flag,dev,buf,len) end
  
  ------获取条件数组
  mifary=xmap.msd_if("IR");

  ------返回硬件标识
  return "IRSensor";
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)

     j=string.format("{\"cmd\":\"ctl_ir\",\"name\":\"%s\"}",scene_name);
     xmap.msd_send(flag,dev,j,#j);

end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)    
    if "scene"== command then    
        j="{\"cmd\":\"get_ir\"}";
        xmap.msd_send(flag,dev,j,#j);
        
    elseif "add_ir"== command then
    
        print("parameter="..parameter);
        
        ta=xstr.split(parameter,",");
        name=ta[0];
        title=ta[1];
        type=ta[2];
        hex=ta[3];
        j= string.format("{\"cmd\":\"add_ir\",\"name\":\"%s\",\"title\":\"%s\",\"type\":\"%s\",\"hex\":\"%s\"}",
                            name,title,type,hex);
        xmap.msd_send(flag,dev,j,#j);
        
    elseif "del_ir"== command then
        j= string.format("{\"cmd\":\"del_ir\",\"name\":\"%s\"}",parameter)
        xmap.msd_send(flag,dev,j,#j);
        
    elseif "settitle"== command then
        ta=xstr.split(parameter,",");
        name=ta[0];
        title=ta[1];
        j= string.format("{\"cmd\":\"settitle\",\"name\":\"%s\",\"title\":\"%s\"}",name,title)
        xmap.msd_send(flag,dev,j,#j);
        
    end
end

------------------------------------------------------------
--MSD设备的数据
function from_mqtt(flag,dev,buf,len)
     
     print(flag ,dev, buf);
     cmd=sjson.attr_get(buf,"cmd");
     
     if("data_rb"==cmd)then

              fmt=sjson.attr_get(buf,"fmt");
              hex=sjson.attr_get(buf,"hex");

              if("NEC_R"~=fmt)then
              
                   --返回到界面显示的JSON内容
                   sj= string.format("{\"ir\":\"%s\",\"fmt\":\"%s\"}",hex,fmt)
                   xmap.msd_udata(flag,dev,"state",sj);

                   --遍历所有MSD_IF
                   for i,v in ipairs(mifary) do
                      --去掉所有空格
                      cmphex=string.gsub(v[3], " ", "");
                      if(cmphex==hex)then
                            --搜索wall场景
                            xmap.box(v[1],v[4]);
                      end
                   end 
                   
              end
              
     elseif("ir_list"==cmd)then
     
              ------创建场景
              scene0="";
              scene0=sjson.attr(scene0,"url","http://xmap.hx-kong.com/ico");
              --
              cnt=sjson.array_count(buf,"list");
              --print("cnt=============="..cnt);
              for i=0,cnt-1,1 do
                  list=sjson.array_get_obj(buf,"list",i);
                  name=sjson.attr_get(list,"name");
                  txt=sjson.attr_get(list,"txt");
                  type=sjson.attr_get(list,"type");
                  hex=sjson.attr_get(list,"hex");
                  scene0=sjson.array(scene0, "scene", "ico=on1.png&txt="..txt.."&name="..name.."&type="..type.."&hex="..hex);
              end
              if(0==cnt)then
                  scene0=sjson.array_nil(scene0, "scene");
                  --print("scene=============="..scene0);
              end
              --
              xmap.msd_udata(flag,dev,"scene", scene0);
              
     elseif("ctl_ir_rb"==cmd)then  
              xmap.msd_udata(flag,dev,"ctl_ir_rb", "");
              
     elseif("add_ir_rb"==cmd)then  
              xmap.msd_udata(flag,dev,"add_ir_rb", "");
            
     elseif("del_ir_rb"==cmd)then  
              xmap.msd_udata(flag,dev,"del_ir_rb", "");
              
     elseif("settitle_rb"==cmd)then  
              xmap.msd_udata(flag,dev,"settitle_rb", "");
              
     elseif("error"==cmd)then
              print(flag ,dev, "ir sensor error");
     end
     
end
