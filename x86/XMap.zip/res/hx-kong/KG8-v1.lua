--[[
协议取用json格式

查询        {"cmd":"check"}
全关        {"cmd":"allclose"}
全开        {"cmd":"allopen"}
单路控制    {"cmd":"set","id":3,"onoff":1}

硬件的状态回复
"cmd":"status","kg":"%s"}

]]--

local xmap=require "xmap" 
local hxnet=require "hxnet" 
local sjson=require "sjson" 
local scene0="";

function module_init()
 ------注册事件
 register_event("user_use_scene");     --function user_use_scene(flag,dev,scene_name,parameter) end
 register_event("from_user");          --function user_get_scene(flag,dev,command,parameter) end
 register_event("from_mqtt");          --function from_mqtt(flag,dev,buf,len) end
 
 ------创建场景0
 scene0=sjson.attr(scene0,"url","http://xmap.hx-kong.com/ico");
 scene0=sjson.array(scene0, "id", "0");
 scene0=sjson.array(scene0, "scene", "group=0&name=ALLON&ico=on1.png&txt=全开");
 scene0=sjson.array(scene0, "scene", "group=0&name=ALLOFF&ico=off1.png&txt=全关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S11&ico=on1.png&txt=1路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S10&ico=off1.png&txt=1路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S21&ico=on1.png&txt=2路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S20&ico=off1.png&txt=2路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S31&ico=on1.png&txt=3路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S30&ico=off1.png&txt=3路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S41&ico=on1.png&txt=4路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S40&ico=off1.png&txt=4路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S51&ico=on1.png&txt=5路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S50&ico=off1.png&txt=5路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S61&ico=on1.png&txt=6路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S60&ico=off1.png&txt=6路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S71&ico=on1.png&txt=7路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S70&ico=off1.png&txt=7路关");
 scene0=sjson.array(scene0, "scene", "group=0&name=S81&ico=on1.png&txt=8路开");
 scene0=sjson.array(scene0, "scene", "group=0&name=S80&ico=off1.png&txt=8路关");

 ------返回硬件标识
 return "KG8";
end

-----------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
   --print("KG4 user_use_scene="..scene_name,parameter);
   if scene_name=="ALLON" then 
       j="{\"cmd\":\"allopen\"}";
   elseif scene_name=="ALLOFF" then
       j="{\"cmd\":\"allclose\"}";
   
   --单路控制
   elseif scene_name=="S10" then
       j="{\"cmd\":\"set\",\"id\":0,\"onoff\":0}";
   elseif scene_name=="S20" then
       j="{\"cmd\":\"set\",\"id\":1,\"onoff\":0}";
   elseif scene_name=="S30" then
       j="{\"cmd\":\"set\",\"id\":2,\"onoff\":0}";
   elseif scene_name=="S40" then
       j="{\"cmd\":\"set\",\"id\":3,\"onoff\":0}";
   elseif scene_name=="S50" then
       j="{\"cmd\":\"set\",\"id\":4,\"onoff\":0}";
   elseif scene_name=="S60" then
       j="{\"cmd\":\"set\",\"id\":5,\"onoff\":0}";
   elseif scene_name=="S70" then
       j="{\"cmd\":\"set\",\"id\":6,\"onoff\":0}";
   elseif scene_name=="S80" then
       j="{\"cmd\":\"set\",\"id\":7,\"onoff\":0}";
   
   
   elseif scene_name=="S11" then
       j="{\"cmd\":\"set\",\"id\":0,\"onoff\":1}";
   elseif scene_name=="S21" then
       j="{\"cmd\":\"set\",\"id\":1,\"onoff\":1}";
   elseif scene_name=="S31" then
       j="{\"cmd\":\"set\",\"id\":2,\"onoff\":1}";
   elseif scene_name=="S41" then
       j="{\"cmd\":\"set\",\"id\":3,\"onoff\":1}";
   elseif scene_name=="S51" then
       j="{\"cmd\":\"set\",\"id\":4,\"onoff\":1}";
   elseif scene_name=="S61" then
       j="{\"cmd\":\"set\",\"id\":5,\"onoff\":1}";
   elseif scene_name=="S71" then
       j="{\"cmd\":\"set\",\"id\":6,\"onoff\":1}";
   elseif scene_name=="S81" then
       j="{\"cmd\":\"set\",\"id\":7,\"onoff\":1}";
       
   end;
   
   xmap.msd_send(flag,dev,j,#j);
end

-----------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)    
       print("from_user--",flag,dev,command,parameter);
   if "scene"== command then
       --print(utf8_gb2312("获取场景内容"));
       if "0"==parameter then
           --print(flag ,dev, scene0);
           xmap.msd_udata(flag,dev,"scene", scene0);
       end
   elseif "state"== command then
       --print(utf8_gb2312("查询硬件状态"));
       j="{\"cmd\":\"check\"}";
       xmap.msd_send(flag,dev,j,#j)
   end
end

-----------------------------------------------------------
--MSD设备的数据
function from_mqtt(flag,dev,buf,len) 
    cmd=sjson.attr_get(buf,"cmd");
    if("status"==cmd)then
        kg=sjson.attr_get(buf,"kg");
        sj= string.format("{\"state\":[%s,%s,%s,%s,%s,%s,%s,%s]}",string.sub(kg,1,2),string.sub(kg,3,4),string.sub(kg,5,6),string.sub(kg,7,8),
                                                string.sub(kg,9,10),string.sub(kg,11,12),string.sub(kg,13,14),string.sub(kg,15,16))
        xmap.msd_udata(flag,dev,"state",sj);
   end
end
