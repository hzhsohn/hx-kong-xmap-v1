--[[
协议取用hx-net格式
字符串标识为 MKG
------->发至MCU
0x00 & ::::::::::::: 查询状态
0x01 & 循环[uchar 通道号码0~通道数量n排列的状态] ::::::::::::: 批量通道开关
0x02 & uchar 通道号码,uchar 开或关0_1 ::::::::::::: 单通道开关控制
------->返回至控制端
0x10 & 循环[uchar 通道号码0~n的状态] ::::::::::::: 通道状态
]]--

local xmap=require "xmap" 
local hxnet=require "hxnet" 
local sjson=require "sjson" 
local scene0="";

function module_init()
  ------注册事件
  register_event("user_use_scene");     --function user_use_scene(flag,dev,scene_name,parameter) end
  register_event("from_user");          --function user_get_scene(flag,dev,command,parameter) end
  register_event("from_mqtt");          --function from_mqtt(flag,dev,buf,len) end
  
  ------创建场景0
  scene0=sjson.attr(scene0,"url","http://res.hx-kong.com/ico");
  scene0=sjson.array(scene0, "id", "0");
  scene0=sjson.array(scene0, "scene", "group=0&name=on&ico=on1.png&txt=开");
  scene0=sjson.array(scene0, "scene", "group=0&name=off&ico=off1.png&txt=关");

  ------返回硬件标识
  return "MKG";
end

------------------------------------------------------------
--MSD设备处理的场景
function user_use_scene(flag,dev,scene_name,parameter)
    if scene_name=="on" then 
        print(utf8_gb2312("MKG发送开"));
        da,dalen=hxnet.create("MKG",string.char(0x01,0x01),2);
        bf,le=data2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    elseif scene_name=="off" then
        print(utf8_gb2312("MKG发送关"));
        da,dalen=hxnet.create("MKG",string.char(0x01,0x00),2);
        bf,le=data2json(da,dalen);
        xmap.msd_send(flag,dev,bf,le);
    else
        print(utf8_gb2312("执行了未知场景->"),flag,dev,scene_name);
    end;
end

------------------------------------------------------------
--用户发送过来的数据
function from_user(flag,dev,command,parameter)    
    if "scene"== command then
        print(utf8_gb2312("获取场景内容"));
        if "0"==parameter then      
            print(flag ,dev, scene0);
            xmap.msd_udata(flag,dev,"scene", scene0);
        end
    elseif "state"== command then         
        print(utf8_gb2312("查询硬件状态"));
        bf,le=data2json(string.char(0xAA,0x4D,0x4B,0x47,0x00,0x01,0x00,0xBA),8);
        xmap.msd_send(flag,dev,bf,le);
    end
end

------------------------------------------------------------
--MSD设备的数据
function from_mqtt(flag,dev,buf,len) 
    --print("---------------------------------------");
    --print("MKG from_mqtt=",len,flag ,dev);
    --解出单片机数据
    msdbuf,msdlen=json2data(buf,len);
    --print("---msd msdlen  --> "..msdlen);
    --print("---msd msdlen  --> "..byte_string(msdbuf,msdlen));
 
    prol_flag,param,param_len=hxnet.getframe(msdbuf,msdlen);
    if prol_flag=="MKG" then                  --判断是否为 MKG协议
        if string.byte(param,1)==0x10 then
             sj= string.format("{\"state\":[%d]}",string.byte(param,2))
             xmap.msd_udata(flag,dev,"state",sj);
             --print(sj);           
         end
    end
end
